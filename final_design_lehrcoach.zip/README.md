
  # Digital Services | Medan City Government Official Portal (Community)

  This is a code bundle for Digital Services | Medan City Government Official Portal (Community). The original project is available at https://www.figma.com/design/LlQVXUAheoYtn79M6jGhX0/Digital-Services-%7C-Medan-City-Government-Official-Portal--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  